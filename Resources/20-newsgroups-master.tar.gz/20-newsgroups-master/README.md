20-newsgroups
=============

A Python implementation of a Naive-Bayes classifier applied to data from the 20 newsgroups data set.

How to run:

>>> python nb-classifier.py --docroot=/path/to/documents
--database=/path/to/knowledge/base
--stop-list=/path/to/file/with/stop/words
